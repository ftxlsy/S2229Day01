﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ant
{
    class Program
    {
        static void Main(string[] args)
        {
            Ant ant = new Ant();
            ant.SayHi("小不点");
            Console.ReadLine();
        }
    }
}
