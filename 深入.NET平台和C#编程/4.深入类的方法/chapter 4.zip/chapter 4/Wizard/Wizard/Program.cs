﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wizard
{
    class Program
    {
        static void Main(string[] args)
        {
            Wizad wizad1 = new Wizad();
            Wizad wizad2 = new Wizad("20","500000","60000"); 
            Console.ReadLine();
        }
    }
}
