﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Count
{
    class Count
    {
        public int Sum(int num1,int num2)
        {
            return num1 + num2;
        }
        public double Sum(double num1, double num2, double num3)
        {
            return num1 + num2 + num3;
        }
        public string Sum(string num1, string num2)
        {
            return num1 + num2;
        }
    }
}
